قـــــنأْةَ ألسـورسَ ✋🏿👇🏻Source channel
# [ASD_KARBALA](https://telegram.me/S94IQ)


*******************************************************************
```sh

# Let's install the bot.
افتـح ترمنـــأل وخلي 👇🏿 Open Terminal and vinegary

sudo apt-get update 

ورهأَ خلي 👇🏿 And vinegary

redis-server
تركه مفتوح✋🏿  Leave it open Terminal

وفتح ترمنال ثاني وخلي 👇🏿 Open Terminal and second vinegary
************************************************************
sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev libjansson* libpython-dev make unzip git redis-server g++ -y --force-yes
************************************************************
ورأهأَ خلي👇🏿
**************
git clone https://github.com/SAJJAD94/ASD_KARBALA.git
*****************************************************
ورهأ خلي 👇🏿 And vinegary
**************************
cd ASD_KARBALA
**************************
ورهأَ خلي👇🏿 And vinegary
**************************
chmod +x launch.sh
**************************
ورهأَ خلي👇🏿 And vinegary
**************************
./launch.sh install
**************************
ورهأَ خلي👇🏿 And vinegary
**************************
./launch.sh 
**************************
يطلب رقم خلي رقم البوت ✋🏿😘
مبروك عليك افضل بوت عل تلي 😍

# Enter a phone number & confirmation code.
Congratulations, you better bot
```
### One command
To install everything in one command (useful for VPS deployment) on Debian-based distros, use:

لتنصيب البوـب بكوَدَ واحد فقط َ ✋🏿😘👇🏿 To install one code

فتح ترمنال وخلي 👇🏿 Open Terminal and vinegary
*******************
sudo apt-get update 
*******************
ورهأَ خلي 👇🏿 And vinegary
*******************
redis-server
*******************
تركه مفتوح✋🏿 Leave it open Terminal

وفتح ترمنال ثاني وخلي 👇🏿 Open Terminal and second vinegary
```sh

sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev libjansson* libpython-dev make unzip git redis-server g++ -y --force-yes && git clone https://github.com/SAJJAD94/ASD_KARBALA.git && cd ASD_KARBALA && chmod +x launch.sh && ./launch.sh install && ./launch.sh
```

* * *
يطلب رقم خلي رقم البوت ✋🏿😘
مبروك عليك افضل بوت عل تلي 😍

# Enter a phone number & confirmation code.
Congratulations, you better bot

### Realm configuration

After you run the bot for first time, send it `!id`. Get your ID and stop the bot.

Open ./data/config.lua and add your ID to the "sudo_users" section in the following format:
✋🏿 لتصبح مطور بوتك غير الايدي خاص كونفج بايديك 👇🏿
```
  sudo_users = {
    18293081,
    0,
    YourID
  }
```
😘 مـبروَك أصبَحتـَ مـطورَ بوـتكَ لتوأصل معي 

#Dev : [@SAJJADNOORI](https://telegram.me/SAJJADNOORI)
#Dev_BOT :  [@S94_BOT](https://telegram.me/S94_BOT)
#Dev_Channel :  [@S94IQ](https://telegram.me/S94IQ)

عندكَ فكره تطوير السورس او البوت تفظل هنأَ☝🏿️
You have an idea to develop Alsoors or bot prefer ☝🏿️✋🏿
