do 

local function run(msg, matches) 

if ( msg.text ) then

  if ( msg.to.type == "user" ) then

     return "للتحدث مع المطور اضغط على المعرف التالي \n @z557z\n او اذا محظور اضغط هنا \n @istaraliraq_bot\n قنأة البوت \n @IrAqIiNtV �"
     
  end 
   
end 

-- #DEV @IrAqIiNtV

end 

return { 
  patterns = { 
       "(.*)$"
  }, 
  run = run, 
} 

end 
-- By @z557z