--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY BADR SAMAWA                  ▀▄ ▄▀ 
▀▄ ▄▀     BY BADR SAMAWA (@z557z)    ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY BADR SAMAWA          ▀▄ ▄▀   
▀▄ ▄▀          dev1  : dev                 ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]
do

function run(msg, matches)
return [[

Bot, who works on the supergroups🔸

Bot to work on the super groups of up to 5 k Membe🔷

     ≪It has been making the bot by the developer≫
                      『 @z557z 』
            🔹#Dev #@IrAqIiNtV🔹
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"dev1$"
},
run = run 
}
end