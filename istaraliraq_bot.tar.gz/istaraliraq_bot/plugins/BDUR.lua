-- made by { @Mouamle }
do
ws = {}
rs = {}

-- some examples of how to use this :3 
ws[1] =  "@z557z" -- ms
rs[1] =  "@z557z ولك جيب ام الياي وتعال صارت عركة وي جماعتنه"❤️🙈" -- reply