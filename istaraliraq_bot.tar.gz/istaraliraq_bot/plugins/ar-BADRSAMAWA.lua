--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY iraqiintv                    ▀▄ ▄▀ 
▀▄ ▄▀     BY iraqiintv  (@z557z)    ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY iraqiintv           ▀▄ ▄▀   
▀▄ ▄▀          Dev  : المطور               ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]

do

function run(msg, matches)
  return '❣ t \n❣   #المطور : @z557z \n❣ #بوت_المطور @istaraliraq_bot \n ❣ #قناة_البوت : @iraqiintv'
end

return {
  patterns = {
    "^الاصدار"
  }, 
  run = run 
}

end