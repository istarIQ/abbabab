--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY iraqiintv                    ▀▄ ▄▀ 
▀▄ ▄▀     BY iraqiintv  (@z557z ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY iraqiintv           ▀▄ ▄▀   
▀▄ ▄▀          dev1  : dev                 ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]
do

function run(msg, matches)
return [[

االبوت الذي يعمل على مجوعات السوبر 🔸

يعمل البوت على مجموعات سوبر تصل الى5k عضو 🔷

     ≪تم صنع البوت بواسطة المطور≫
                      『 @z557z 』
            🔹#Dev @itsaraliraq_bot
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"dev$"
},
run = run 
}
end