do

local function callback(extra, success, result)
  vardump(success)
  vardump(result)
end

local function run(msg, matches)
 if matches[1] == 'اضف المطور' then
        chat = 'chat#'..msg.to.id
        user1 = 'user#'..189166802
        chat_add_user(chat, user1, callback, false)
	return "تم اضافت المطور"
      end
if matches[1] == 'اضف المطور' then
        chat = 'chat#'..msg.to.id
        user2 = 'user#'..137323539
        chat_add_user(chat, user2, callback, false)
	return "م اضافت المطور"
      end
 
 end

return {
  description = "Invite Sudo and Admin", 
  usage = {
    "/addsudo : invite Bot Sudo", 
	},
  patterns = {
    "^[!/#$](اضف المطور)",
    "^[!/#$](اضف المطور)",
    "^/(add dev)",
    "^/(add dev)",
  }, 
  run = run,
}
-- arabic : @Omar_Real

end
